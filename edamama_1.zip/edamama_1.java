package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class edamama_1 {
	public static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Installer\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("disable-notifications");
		//WebDriver driver = new ChromeDriver(option);
		driver = new ChromeDriver(option);
		driver.manage().window().maximize();
		driver.get("https://www.edamama.ph/shop");
		Thread.sleep(3000);
		driver.findElement(By.id("moe-dontallow_button")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Login')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("mat-input-0")).sendKeys("amudholkar52@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("Abhishek@123");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//img[@class=\"ng-tns-c104-0\"])[2]")).click();
		edamama_1.userList("Wishlist");
	}

	public static void userList(String value) {
		driver.findElement(By.xpath("//button[contains(text(),'" + value + "')]")).click();
	}
}
